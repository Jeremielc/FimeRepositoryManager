#!/bin/bash
java -jar RemanWsProjectTest-v2.0-stable.jar
