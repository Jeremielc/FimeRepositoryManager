#!/bin/bash
java -jar RemanWsProjectTest-v1.0-stable.jar
